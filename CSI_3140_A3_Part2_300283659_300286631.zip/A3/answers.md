# Part 1 (40 marks)

## Q1) True or False? (6 marks)

a) **False.**
   PHP types are dynamic. No declaration needed.

b) **False.**
   XML is for data structure & transport, not display.

c) **True.**

d) **False.**
   `insertBefore` is called on the parent node, not always `document`.

e) **True.**
   This is called type juggling.

f) **False.**
   Ajax can use other formats like JSON or plain text.

## Q2) Fill in the blanks. (8 marks)

a) `length`

b) `returnValue`

c) `XMLHttpRequest`

d) `database`

e) `$_GET`

f) `WHERE`

g) `valid`

h) `integer`, `float`

## Q3) XML vs. HTML differences. (4 marks)

*   **Purpose:** HTML displays data (web pages). XML transports/stores data.
*   **Syntax:** HTML has preset tags. XML has custom tags. XML is stricter (case-sensitive, must close tags).

## Q4) Client-Server Model. (3 marks)

1.  **Client (browser)** requests a resource via URL.
2.  **Server** gets the request, finds the resource.
3.  **Server** sends it back. Browser shows it.

## Q5) $_GET vs. $_POST. (2 marks)

*   **`$_GET`**: Data sent in the URL. Visible. Size limit.
*   **`$_POST`**: Data sent in request body. Hidden. No real size limit.

## Q6) `include` vs. `require`. (2 marks)

*   **Purpose:** Both insert a PHP file's content into another. For code reuse.
*   **Error Handling:** If file not found, `include` gives a warning and continues. `require` gives a fatal error and stops.

## Q7) SQL Query. (3 marks)

```sql
SELECT productName, price
FROM products
WHERE category = 'Electronics' AND price > 500;
```

## Q8) PHP Script Output. (4 marks)

**Output:** `Final Result: 198`

**Why:**
The script loops through `[1, 2, 3, 4, 5, 6]`. It starts with `$result = 1`, adds odd numbers, and multiplies by even numbers.

`1+1=2` -> `2*2=4` -> `4+3=7` -> `7*4=28` -> `28+5=33` -> `33*6=198`.

## Q9) PHP Price Calculation Function. (8 marks)

```php
<?php
function calculateFinalPrice($initialPrice, $userStatus, $membershipYears) {
    $discount = 0.0;

    // Set base discount
    if ($userStatus === 'vip') {
        $discount = 0.20;
    } elseif ($userStatus === 'member') {
        $discount = 0.10;
    }

    // Add extra discount for loyal members
    if (($userStatus === 'vip' || $userStatus === 'member') && $membershipYears >= 5) {
        $discount += 0.05;
    }

    // Return final price
    return $initialPrice * (1 - $discount);
}
?>
